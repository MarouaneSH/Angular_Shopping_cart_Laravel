export let products = [
  {
    name : 'Rice, Grain & Pasta',
    categorie : 'Dairy',
    subcategorie:'Rice',
    url : 'Dairy/1.jpg',
  },
  {
    name : 'Dairy & Deli',
    categorie : 'Dairy',
    subcategorie:'Deli',
    url : 'Dairy/2.jpg',
  },
  {
    name : 'Frozen & Deli',
    categorie : 'Dairy',
    subcategorie:'Frozen',
    url : 'Dairy/3.png',
  },
  {
    name : 'Oils & Olives',
    categorie : 'Dairy',
    subcategorie:'Oils',
    url : 'Dairy/4.jpg',
  },
  {
    name : 'Pickles & Stuff',
    categorie : 'sweet',
    subcategorie:'Pickles',
    url : 'Dairy/5.jpg',
  },
  {
    name : 'Spices & Flavours',
    categorie : 'sweet',
    subcategorie:'Spices',
    url : 'Dairy/6.jpg'
  }
];
