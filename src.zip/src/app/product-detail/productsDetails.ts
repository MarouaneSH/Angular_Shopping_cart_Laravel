export let productsDetails = [
  {
    categorie : 'Rice',
    name: 'GW Rice',
    url: '1.jpg'
  },
  {
    categorie : 'Rice',
    name: 'Couscous',
    url: '2.jpg'
  }
  ,
  {
    categorie : 'Rice',
    name: ' Wheat, Barley',
    url: '3.jpg'
  }

]
